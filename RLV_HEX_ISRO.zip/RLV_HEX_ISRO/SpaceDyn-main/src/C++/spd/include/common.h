typedef double Vector3[3];
typedef double Vector4[4];
typedef double Vector5[5];
typedef double Vector6[6];
typedef double Vector7[7];
typedef double Vector8[8];
typedef double Vector9[9];

typedef double Matrix3[3*3];
typedef double Matrix4[4*4];
typedef double Matrix5[5*5];
typedef double Matrix6[6*6];
typedef double Matrix7[7*7];
typedef double Matrix8[8*8];
typedef double Matrix9[9*9];
