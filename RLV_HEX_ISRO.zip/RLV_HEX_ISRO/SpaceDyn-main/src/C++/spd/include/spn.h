void crossF ( double *, double * );
void crossM ( double *, double * );
void spI ( double , double *, double *, double * );

void XrotBB( double *, double * );
void XrotAA( double *, double * );

void Xtrans ( double *, double * );
void Xrotx( double , double * );
void Xroty( double , double * );
void Xrotz( double , double * );

void i_tilde( double *, double *);
