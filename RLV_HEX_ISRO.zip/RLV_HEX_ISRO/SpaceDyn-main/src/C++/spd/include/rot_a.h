void rpy2R ( double *, double * );
void R2rpy ( double *, double * );
void R2qtn ( double *, double * );
void rpy2qtn ( double *, double * );

void tilde ( double *, double *);

double pi_conv( char *data );
double pi2deg( double pi );
double deg2pi( double deg );

void QMultiply( double *, double *, double * );
