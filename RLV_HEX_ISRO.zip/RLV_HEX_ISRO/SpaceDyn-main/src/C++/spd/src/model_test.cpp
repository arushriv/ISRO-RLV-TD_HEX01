//_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_//
//
// Function : model( string, MODEL )
//            Read Model Parameters into Spatial Notation
//            from model file
//
// s.abiko [2007.5]
//
//_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_//
//#include "../matrix/matrix.h"
//#include "../matrix/vector.h"
//#include "../include/rot.h"
//#include "../include/spn.h"
//#include "../include/spd.h"

#include <string>
using namespace std;
//#define _LINESKIP ifs >> str;

void model_test( string filename )
{
   
}

// === EOF ===
